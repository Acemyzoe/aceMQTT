#ifndef NANOMQ_BENCH_H
#define NANOMQ_BENCH_H

extern int bench_start(int argc, char **argv);
extern int bench_dflt(int argc, char **argv);

#endif //NANOMQ_BENCH_H