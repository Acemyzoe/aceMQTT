extern int mqcreate_debug(int argc, char **argv);
extern int mqsend_debug(int argc, char **argv);
extern int mqreceive_debug(int argc, char **argv);
extern int dashboard_data_sync(int argc, char **argv);
