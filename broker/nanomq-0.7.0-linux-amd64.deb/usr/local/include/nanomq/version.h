#define FW_EV_VER_MAJOR 6
#define FW_EV_VER_MINOR 3
#define FW_EV_VER_PATCH 0
#define FW_EV_VER_ID_SHORT "3"
#define FW_EV_VER_ID_LONG "100"
